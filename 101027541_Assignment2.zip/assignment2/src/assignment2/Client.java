package assignment2;

import java.io.IOException;
import java.net.*;

public class Client {
	DatagramPacket sendPacket, receivePacket;
	DatagramSocket sendReceiveSocket;

	public Client() {
		try {
			sendReceiveSocket = new DatagramSocket();
		} catch (SocketException se) {
			se.printStackTrace();
			System.exit(1);
		}
	}

	public void sendAndReceive(String requestType, String filename, String mode) {
		// Prepare a DatagramPacket and send it via
		// sendReceiveSocket to port 23 on the destination
		// host.
		byte[] requestFormat = createRequestFormat(requestType, filename, mode);
		String r = buildString(requestFormat);
		try {
			this.sendPacket = new DatagramPacket(requestFormat, requestFormat.length, InetAddress.getLocalHost(), 23);
		} catch (UnknownHostException e) {
			e.printStackTrace();
			System.exit(1);
		}

		System.out.println("Client: Sending packet:");
		System.out.println("To host: " + this.sendPacket.getAddress());
		System.out.println("Destination host port: " + this.sendPacket.getPort());
		int length = this.sendPacket.getLength();
		System.out.println("Length: " + length);
		System.out.print("Containing: ");
		System.out.println(new String(this.sendPacket.getData(), 0, length));

		System.out.println(r);

		try {
			this.sendReceiveSocket.send(this.sendPacket);
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
		System.out.println("Client: Packet sent.\n");
		byte d[] = new byte[512];
		this.receivePacket = new DatagramPacket(d, d.length);
		try {
			this.sendReceiveSocket.receive(receivePacket);
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
		System.out.println("Client: Packet received.");
		System.out.println("From host: " + this.receivePacket.getAddress());
		System.out.println("Host port: " + this.receivePacket.getPort());
		length = this.receivePacket.getLength();
		System.out.println("Length: " + length);
		System.out.print("Containing: ");
		String received = new String(d, 0, length);
		System.out.println(received);
		System.out.println(buildString(d));
		// sendReceiveSocket.close();
	}

	private static String buildString(byte[] bytes) {
		StringBuilder builder = new StringBuilder();
		for (byte b : bytes) {
			builder.append(String.format("%02X ", b));
		}
		return builder.toString();
	}

	private static byte[] createRequestFormat(String type, String filename, String mode) {
		byte data[] = new byte[4 + filename.length() + mode.length()];
		// data.add((byte)0);
		data[0] = (byte) 0;
		if (type == "read") {
			data[1] = (byte) 1;
		} else if (type == "write") {
			data[1] = (byte) 2;
		} else {
			data[1] = ((byte) 0xf);
			// means request type unclear;
		}
		byte[] filenameByte = filename.getBytes();
		int j = 2;
		for (int i = 0; i < filenameByte.length; i++) {
			data[j] = (filenameByte[i]);
			j++;
		}
		data[j] = (byte) 0;
		j++;
		byte[] modeByte = mode.getBytes();
		for (int k = 0; k < modeByte.length; k++) {
			data[j] = (modeByte[k]);
			j++;
		}
		data[j] = (byte) 0;
		j++;
		byte[] output = new byte[data.length];
		for (int l = 0; l < data.length; l++) {
			output[l] = data[l];
		}
		return output;
	}

	private void loop() {
		for (int i = 0; i < 11; i++) {
			if (i == 10) {
				this.sendAndReceive("read", "101027541_Assignment2.pdf", "Last One");
			} else if (i % 2 == 1) {
				this.sendAndReceive("read", "test1.txt", "ocTet");
			} else if (i % 2 == 0) {
				this.sendAndReceive("write", "test2.txt", "netaSCII");
			}
		}
	}

	public static void main(String args[]) throws IOException {
		Client c = new Client();
		c.loop();
	}

}