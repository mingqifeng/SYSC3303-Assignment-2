package assignment2;

import java.io.IOException;
import java.net.*;

import com.sun.media.sound.InvalidFormatException;

public class Server {

	private DatagramPacket sendPacket, receivePacket;
	private DatagramSocket sendSocket, receiveSocket;
	private static final byte[] valid_read = { (byte) 0, (byte) 3, (byte) 0, (byte) 1 };
	private static final byte[] valid_write = { (byte) 0, (byte) 4, (byte) 0, (byte) 0 };

	public Server() {
		try {
			sendSocket = new DatagramSocket();
			receiveSocket = new DatagramSocket(69);
		} catch (SocketException se) {
			se.printStackTrace();
			System.exit(1);
		}
	}

	private static String buildString(byte[] bytes) {
		StringBuilder builder = new StringBuilder();
		for (byte b : bytes) {
			builder.append(String.format("%02X ", b));
		}
		return builder.toString();
	}

	private void parse(DatagramPacket packet) throws InvalidFormatException {
		byte[] dat = packet.getData();
		if (dat[0] != (byte) 0) {
			throw new InvalidFormatException("first Bytes for request type is wrong!");
		}
		if ((dat[1] == (byte) 1) || (dat[1] == (byte) 2)) {
		} else {
			System.out.println("ERROR in second byte.");
			System.exit(1);
		}
		boolean zeroBetweenString = false;

		if (dat[dat.length - 1] != (byte) 0) {
			throw new InvalidFormatException("Bytes for the last digit is wrong!");
		}

		for (int i = 2; i < packet.getLength() - 1; i++) {
			if (dat[i] == 0x0) {
				zeroBetweenString = true;
			}
		}
		if (zeroBetweenString == false) {
			throw new InvalidFormatException("There is no byte 0 between filename and mode!");
		}

	}

	private void receiveRequest(byte data[]) {
		System.out.println("Waiting to receive from Intermediate Host...");
		try {
			System.out.println("Waiting to receive from Intermediate Host...");
			receiveSocket.receive(receivePacket);
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
		System.out.println("Server: Packet received from host:");
		System.out.println("From host: " + receivePacket.getAddress());
		System.out.println("Host port: " + receivePacket.getPort());
		int len = receivePacket.getLength();
		System.out.println("Length: " + len);
		System.out.print("Containing: ");
		String received = new String(data, 0, len);
		System.out.println(received);
		System.out.println(buildString(data));

	}

	private void sendRequest(byte data[]) {
		sendPacket = new DatagramPacket(data, data.length, receivePacket.getAddress(), receivePacket.getPort());
		System.out.println("Server: Sending packet to host:");
		System.out.println("To host: " + sendPacket.getAddress());
		System.out.println("Destination host port: " + sendPacket.getPort());
		int len = sendPacket.getLength();
		System.out.println("Length: " + len);
		System.out.print("Containing: ");
		System.out.println(new String(sendPacket.getData(), 0, len));
		System.out.println(buildString(data));
		try {
			sendSocket.send(sendPacket);
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
		System.out.println("Server: packet sent to host.");
	}

	private void sendAndReceive() {
		byte data[] = new byte[100];
		receivePacket = new DatagramPacket(data, data.length);
		int i = 1;
		while (true) {
			System.out.println(i + ":");
			i++;
			this.receiveRequest(data);
			try {
				this.parse(receivePacket);
			} catch (InvalidFormatException e) {
				e.printStackTrace();
				System.exit(1);
			}

			System.out.println("Server: Create response packet.");
			if (data[1] == (byte) 1) {
				this.sendRequest(valid_read);
			}
			if (data[1] == (byte) 2) {
				this.sendRequest(valid_write);
			}
		}

	}

	public static void main(String args[]) {
		Server server = new Server();
		server.sendAndReceive();
	}

}
