package assignment2;

import java.io.IOException;
import java.net.*;

public class Host {

	private DatagramSocket receiveSocket, sendReceiveSocket, sendSocket;
	private DatagramPacket receivePacket, sendPacket;
	private int clientPort;
	private InetAddress clientAddr;

	public Host() {
		try {
			receiveSocket = new DatagramSocket(23);
			sendSocket = new DatagramSocket();
			sendReceiveSocket = new DatagramSocket();
		} catch (SocketException se) {
			se.printStackTrace();
			System.exit(1);
		}
	}

	private void sendAndReceive() {
		byte[] data = new byte[512];
		receivePacket = new DatagramPacket(data, data.length);
		while (true) {
			this.receiveFromClient(data);
			this.sendToServer(data);
			this.receiveFromServer(data);
			this.sendToClient(data);
		}
	}

	private void receiveFromClient(byte[] data) {
		try {
			System.out.println("Waiting to receive from Client...");
			receiveSocket.receive(receivePacket);
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
		clientAddr = receivePacket.getAddress();
		clientPort = receivePacket.getPort();

		System.out.println("Intermediate Host: Client Packet received:");
		System.out.println("From host: " + receivePacket.getAddress());
		System.out.println("Host port: " + receivePacket.getPort());
		System.out.println("Length: " + receivePacket.getLength());
		System.out.println("Containing:");
		System.out.println(new String(data, 0, receivePacket.getLength()));
		System.out.println(buildString(data));
	}

	private void sendToClient(byte[] data) {
		sendPacket = new DatagramPacket(data, receivePacket.getLength(), clientAddr, clientPort);
		System.out.println("Intermediate Host: Sending packet to Server:");
		System.out.println("To host: " + sendPacket.getAddress());
		System.out.println("Host port: " + sendPacket.getPort());
		System.out.println("Length: " + sendPacket.getLength());
		System.out.print("Containing: ");
		System.out.println(new String(sendPacket.getData(), 0, sendPacket.getLength()));
		System.out.println(buildString(sendPacket.getData()));
		try {
			sendSocket.send(sendPacket);
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
		System.out.println("Packet sent to Client.");
	}

	private void receiveFromServer(byte[] data) {
		try {
			System.out.println("Waiting to receive from Server...");
			sendReceiveSocket.receive(receivePacket);

		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
		System.out.println("Intermediate Host: Server Packet received:");
		System.out.println("From host: " + receivePacket.getAddress());
		System.out.println("Host port: " + receivePacket.getPort());
		System.out.println("Length: " + receivePacket.getLength());
		System.out.print("Containing: ");

		String received = new String(data, 0, receivePacket.getLength());
		System.out.println(received);
		System.out.println(buildString(data));
	}

	private void sendToServer(byte[] data) {
		sendPacket = new DatagramPacket(data, receivePacket.getLength(), receivePacket.getAddress(), 69);
		System.out.println("Intermediate Host: Sending packet to Server:");
		System.out.println("To host: " + sendPacket.getAddress());
		System.out.println("Host port: " + sendPacket.getPort());
		System.out.println("Length: " + sendPacket.getLength());
		System.out.print("Containing: ");
		System.out.println(new String(sendPacket.getData(), 0, sendPacket.getLength()));
		System.out.println(buildString(sendPacket.getData()));
		try {
			sendReceiveSocket.send(sendPacket);
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
		System.out.println("Packet sent to Server.");
	}

	private static String buildString(byte[] bytes) {
		StringBuilder builder = new StringBuilder();
		for (byte b : bytes) {
			builder.append(String.format("%02X ", b));
		}
		return builder.toString();
	}

	public static void main(String[] args) {
		Host host = new Host();
		host.sendAndReceive();
	}
}
